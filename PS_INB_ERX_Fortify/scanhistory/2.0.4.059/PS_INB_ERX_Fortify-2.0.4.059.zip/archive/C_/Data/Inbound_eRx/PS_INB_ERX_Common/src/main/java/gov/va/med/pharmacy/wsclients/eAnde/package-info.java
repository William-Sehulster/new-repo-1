@javax.xml.bind.annotation.XmlSchema(namespace = "http://jaxws.webservices.esr.med.va.gov/schemas", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package gov.va.med.pharmacy.wsclients.eAnde;
